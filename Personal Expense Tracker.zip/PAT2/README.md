# Personal Expense Tracker

A simple web application for tracking personal expenses built with Flask, HTML, CSS, and JavaScript. Uses SQLite for data storage.

## Features

- User registration and login
- Add, view, and track expenses
- Categorize expenses
- Secure password hashing

## Installation

1. Clone or download the project files.

2. Install Python if not already installed (version 3.6 or higher).

3. Install the required packages:
   ```
   pip install -r requirements.txt
   ```

## Running the Application

1. Navigate to the project directory.

2. Run the Flask application:
   ```
   python app.py
   ```

3. Open your web browser and go to `http://127.0.0.1:5000/`

## Usage

1. Register a new account or login with existing credentials.
2. Once logged in, you can add new expenses by filling out the form.
3. View your expense history in the table below.

## Project Structure

- `app.py`: Main Flask application
- `templates/`: HTML templates
- `static/css/`: CSS stylesheets
- `static/js/`: JavaScript files (currently empty, can be extended)
- `requirements.txt`: Python dependencies
- `expenses.db`: SQLite database (created automatically)

## Security Note

This is a basic implementation. In a production environment, consider:
- Using environment variables for secret keys
- Implementing proper session management
- Adding input validation and sanitization
- Using HTTPS